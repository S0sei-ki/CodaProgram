update 0.5 8/2/24

added python.html for contact form (unfinished)

added new things from the stye.css for styling the python.html

added new bg for python.html

update 0.7 8/5/24

combined both version of file

contact, about and python pages added wip added for wip

